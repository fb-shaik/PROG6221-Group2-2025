﻿using System.Media;
namespace SoundPlayerDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SoundPlayer player = new SoundPlayer("chime.wav"); 

            Console.WriteLine("Type 'play' and press ENTER to hear a sound.");
            Console.WriteLine("Type 'exit' to quit.");

            while (true)
            {
                Console.Write("Enter command: ");
                string input = Console.ReadLine()?.Trim().ToLower(); // Read input

                if (input == "play")
                {
                    Console.WriteLine("Playing sound...");
                    player.Play(); // Play the sound
                }
                else if (input == "exit")
                {
                    Console.WriteLine("Exiting the program.");
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid command! Type 'play' to hear a sound.");
                }
            }
        }
    }

}
