﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM_Simulator
{
    // Bank Account class to handle deposits and withdrawals
    class BankAccount
    {
        public double Balance { get; private set; } // Read-only balance property

        // Constructor to initialize account with an initial balance
        public BankAccount(double initialBalance)
        {
            Balance = initialBalance;
        }

        // Deposit method to add money to the account
        public void Deposit(double amount)
        {
            Balance += amount;
        }

        // Withdraw method with validation (prevents overdraft)
        public bool Withdraw(double amount)
        {
            if (amount > Balance)
                return false; // Transaction fails if funds are insufficient

            Balance -= amount;
            return true; // Transaction successful
        }
    }
}