﻿namespace ATM_Simulator
{
    class Program
    {// Method to display a formatted decorative border for UI readability
        static void DrawBorder(string title)
        {
            Console.Clear(); // Clear screen before displaying the new section
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(new string('=', 40));
            Console.WriteLine($"== {title.PadRight(34)} ==");
            Console.WriteLine(new string('=', 40));
            Console.ResetColor();
        }

        // ASCII Art to simulate an ATM Welcome Screen
        static void ShowWelcomeScreen()
        {
            DrawBorder("Welcome to ATM Simulator");

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine(@"
            ╔═════════════════════════╗
            ║       ATM SYSTEM        ║
            ╚═════════════════════════╝
            ");
            Console.ResetColor();

            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadLine(); // Wait for user input before proceeding
        }

        // Display ATM Menu for user interaction
        static void DisplayMenu()
        {
            DrawBorder("ATM MENU");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1. Check Balance");
            Console.WriteLine("2. Deposit Money");
            Console.WriteLine("3. Withdraw Money");
            Console.WriteLine("4. Exit");
            Console.ResetColor();

            Console.Write("\nChoose an option: ");
        }

        // Process ATM transactions based on user input
        static void ProcessATM(User user, BankAccount account)
        {
            string choice;
            do
            {
                DisplayMenu(); // Show menu options
                choice = Console.ReadLine()?.Trim(); // Read user choice

                switch (choice)
                {
                    case "1": // Option to check balance
                        DrawBorder("Check Balance");
                        Console.WriteLine($"Hello {user.Name}, Your current balance is: ${account.Balance}");
                        break;

                    case "2": // Option to deposit money
                        DrawBorder("Deposit Money");
                        Console.Write("Enter amount to deposit: ");
                        if (double.TryParse(Console.ReadLine(), out double deposit) && deposit > 0)
                        {
                            account.Deposit(deposit); // Add amount to balance
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine($"Successfully deposited ${deposit}. New Balance: ${account.Balance}");
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Invalid deposit amount.");
                            Console.ResetColor();
                        }
                        break;

                    case "3": // Option to withdraw money
                        DrawBorder("Withdraw Money");
                        Console.Write("Enter amount to withdraw: ");
                        if (double.TryParse(Console.ReadLine(), out double withdraw) && withdraw > 0)
                        {
                            if (account.Withdraw(withdraw)) // Check if withdrawal is possible
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine($"Successfully withdrew ${withdraw}. Remaining Balance: ${account.Balance}");
                                Console.ResetColor();
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Insufficient funds!");
                                Console.ResetColor();
                            }
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Invalid withdrawal amount.");
                            Console.ResetColor();
                        }
                        break;

                    case "4": // Exit option
                        DrawBorder("Thank You for Using ATM!");
                        Console.WriteLine("Have a great day!");
                        break;

                    default: // Invalid input handling
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid option, please try again.");
                        Console.ResetColor();
                        break;
                }

                Console.WriteLine("\nPress Enter to continue...");
                Console.ReadLine(); // Wait for user to press Enter before returning to menu

            } while (choice != "4"); // Loop continues until user chooses to exit
        }

        // Main entry point of the application
        static void Main(string[] args)
        {
            try
            {
                ShowWelcomeScreen(); // Display ATM welcome screen

                // Prompt for user authentication
                DrawBorder("User Authentication");
                Console.Write("Enter your name: ");
                string name = Console.ReadLine()?.Trim();

                Console.Write("Enter your account number: ");
                string accountNumber = Console.ReadLine()?.Trim();

                // Validate user input
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(accountNumber))
                {
                    throw new Exception("Name and account number cannot be empty.");
                }

                // Create User and BankAccount instances
                User user = new User { Name = name, AccountNumber = accountNumber };
                BankAccount account = new BankAccount(500.00); // Initialize account with $500

                ProcessATM(user, account); // Start ATM transactions
            }
            catch (Exception ex) // Error handling
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\nError: {ex.Message}");
                Console.ResetColor();
            }
            finally
            {
                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey(); // Wait for user input before closing
            }
        }
    }
}