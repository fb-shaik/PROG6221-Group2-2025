﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM_Simulator
{
    // User class with automatic properties for storing user information
    class User
    {
        public string Name { get; set; }         // User's Name
        public string AccountNumber { get; set; } // Account Number
    }
}
