﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Threading;

namespace RealOrRizzGame
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.Clear();
                Game game = new Game();
                game.Start();

                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("Play again? (yes/no): ");
                Console.ResetColor();

                string again = Console.ReadLine()?.Trim().ToLower();
                if (again != "yes") break;

            } while (true);

            Console.WriteLine("\nThanks for playing!");
        }
    }

    class Game
    {
        private readonly Dictionary<string, bool> popCultureQuotes;
        private int score = 0;
        private int streak = 0;
        private int bestStreak = 0;

        private SoundPlayer correctSound;
        private SoundPlayer wrongSound;
        private SoundPlayer typingSound;

        public Game()
        {
            popCultureQuotes = new Dictionary<string, bool>()
            {
                { "I don’t chase, I attract.", true },
                { "Hot girl walk to the fridge counts too.", true },
                { "Link in bio for the tea, besties.", true },
                { "If you don’t have a morning routine, who even are you?", false },
                { "Rise, glam, content, repeat.", false },
                { "I live in a hoodie and regret.", true },
                { "Showered? No. Thriving? Also no.", true },
                { "Cereal for dinner is self-care.", true },
                { "Just entered my villain arc because I skipped lunch.", false },
                { "Productivity is a myth invented by morning people.", false },
                { "My toxic trait is thinking one iced coffee will fix my life.", true },
                { "I’m not messy, I’m in my whimsical chaos era.", false },
                { "Gaslight, gatekeep, girlboss.", true },
                { "Caught in 4K being delulu again.", true },
                { "I’m just a manifestation with WiFi.", false },
                { "It’s giving main character energy.", true },
                { "BFFR. Be. For. Real.", true },
                { "Catch flights, not feelings.", true },
                { "My vibe is billionaire in burnout era.", false },
                { "No thoughts, just vibes.", true },
                { "I’m not late, I’m on aesthetic time.", false },
                { "He’s just a silly little guy.", true },
                { "I woke up and chose chaos.", true },
                { "Slay today, slay tomorrow, slay forever.", false },
                { "Mentally I’m at a café in Paris with no responsibilities.", true }
            };

            try
            {
                correctSound = new SoundPlayer("correct.wav");
                wrongSound = new SoundPlayer("wrong.wav");
                typingSound = new SoundPlayer("typing.wav");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error loading sound files: " + ex.Message);
                Console.ResetColor();
            }
        }

        public void Start()
        {
            DrawDivider();
            TypeOut("Welcome to: Real or Rizz? (Gen Z Edition)", ConsoleColor.Cyan);
            DrawDivider();
            TypeOut("Type 'yes' if the quote is real, 'no' if it’s made-up.\n", ConsoleColor.Gray);

            // Randomly select 5 from the full set of 25
            var shuffledQuotes = popCultureQuotes.OrderBy(q => Guid.NewGuid()).Take(5).ToList();

            foreach (var quote in shuffledQuotes)
            {
                TypeOut($"\n{quote.Key}\"", ConsoleColor.Magenta);

                string input = GetUserInput();
                TypeOut("Thinking", ConsoleColor.Yellow);
                LoadingDots();

                bool userGuess = input == "yes";
                bool correctAnswer = quote.Value;

                if (userGuess == correctAnswer)
                {
                    score++;
                    streak++;
                    bestStreak = Math.Max(bestStreak, streak);
                    PlaySound(correctSound);
                    TypeOut("Correct!\n", ConsoleColor.Green);
                }
                else
                {
                    streak = 0;
                    PlaySound(wrongSound);
                    TypeOut($"Wrong! That was actually {(correctAnswer ? "real." : "made-up.")}\n", ConsoleColor.Red);
                }
            }

            ShowFinalScore();
        }

        private string GetUserInput()
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Real or made-up? (yes/no): ");
                Console.ResetColor();

                string input = Console.ReadLine()?.Trim().ToLower();
                if (input == "yes" || input == "no")
                    return input;

                TypeOut("Please enter 'yes' or 'no'.", ConsoleColor.DarkYellow);
            }
        }

        private void TypeOut(string text, ConsoleColor color = ConsoleColor.Gray, int delay = 20)
        {
            Console.ForegroundColor = color;
            try { typingSound?.PlayLooping(); } catch { }

            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }

            try { typingSound?.Stop(); } catch { }

            Console.WriteLine();
            Console.ResetColor();
        }

        private void LoadingDots(int dots = 3, int delay = 300)
        {
            for (int i = 0; i < dots; i++)
            {
                Console.Write(".");
                Thread.Sleep(delay);
            }
            Console.WriteLine();
        }

        private void PlaySound(SoundPlayer sound)
        {
            try { sound?.PlaySync(); } catch { }
        }

        private void ShowFinalScore()
        {
            DrawDivider();
            TypeOut($"\nFinal Score: {score}/5", ConsoleColor.Cyan);

            if (score == 5)
                TypeOut("You are the algorithm. Certified Rizz Master.", ConsoleColor.Green);
            else if (score >= 4)
                TypeOut("Internet Royalty. You scroll like a pro.", ConsoleColor.Green);
            else if (score >= 3)
                TypeOut("Terminally Online — in a good way.", ConsoleColor.Yellow);
            else if (score >= 2)
                TypeOut("You know some stuff, but you’re def not chronically online.", ConsoleColor.Yellow);
            else
                TypeOut("Touch grass, bestie. Or maybe open TikTok once in a while?", ConsoleColor.Red);

            TypeOut($"\nLongest Streak: {bestStreak}", ConsoleColor.Cyan);

            if (bestStreak >= 5)
                TypeOut("Infinity Streak Achieved.", ConsoleColor.Green);
            else if (bestStreak >= 3)
                TypeOut("Mid-Slay Mode Activated.", ConsoleColor.Yellow);
            else if (bestStreak >= 2)
                TypeOut("Tiny Slay Detected.", ConsoleColor.Yellow);
            else
                TypeOut("You were in your Web of Lies era.", ConsoleColor.Red);

            DrawDivider();
        }

        private void DrawDivider()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine(new string('-', 50));
            Console.ResetColor();
        }
    }
}
